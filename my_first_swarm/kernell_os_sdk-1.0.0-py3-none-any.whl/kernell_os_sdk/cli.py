import argparse
import sys
import time
import os
import json
from .__init__ import __version__

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    parser = argparse.ArgumentParser(
        description="Kernell OS SDK CLI - Build Sovereign Autonomous Swarms"
    )
    parser.add_argument("--version", action="version", version=f"kernell-os-sdk {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Init command
    init_parser = subparsers.add_parser("init", help="Interactive wizard to scaffold a new Agent Swarm")
    init_parser.add_argument("name", nargs="?", default="my-swarm", help="Name of the agent project")
    init_parser.add_argument("--yes", action="store_true", help="Accept all defaults without prompting")
    
    # Install command
    install_parser = subparsers.add_parser("install", help="Deploy the agent in its Docker sandbox")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run the agent swarm daemon")
    
    # GUI command
    gui_parser = subparsers.add_parser("gui", help="Launch the local Command Center Dashboard")
    gui_parser.add_argument("--port", type=int, default=3000, help="Port to run the GUI on")
    
    args = parser.parse_args()
    
    if args.command == "init":
        interactive_init(args.name, args.yes)
        
    elif args.command == "install":
        print("📦 Building Kernell OS Sandbox...")
        print("✅ Sandbox Ready.")
        
    elif args.command == "run":
        print("⚙️  Starting Swarm Daemon...")
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down.")
            
    elif args.command == "gui":
        print(f"🖥️  Starting Command Center on http://localhost:{args.port} ...")
        # In a real scenario, this would spin up the Next.js/React server or FastAPI
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down.")
            
    else:
        parser.print_help()
        sys.exit(1)

def interactive_init(project_name, auto_yes):
    clear_screen()
    print("=" * 60)
    print(" KERNELL OS SDK v1.0 — INITIALIZING SOVEREIGN SWARM ")
    print("=" * 60)
    
    # 1. Hardware Scan
    print("\\n[1/3] Scanning Host Hardware for Local Workers...")
    time.sleep(1.5) # Simulate scan
    try:
        from kernell_os_sdk.hardware import HardwareScanner
        profile = HardwareScanner.scan()
        rec = HardwareScanner.recommend_local_llm(profile)
        print(f"      OS: {profile.os_name.upper()} | RAM: {profile.total_ram_gb}GB")
        if profile.has_gpu:
            print(f"      GPU: {profile.gpu_vendor.upper()} | VRAM: {profile.vram_gb}GB")
        print(f"      -> Recommended Local Engine: {rec['model']}")
        local_model = rec['model']
    except Exception as e:
        print(f"      Hardware scan error: {e}")
        local_model = "gemma4:9b"
        
    # 2. Config
    print("\\n[2/3] Project Configuration")
    if not auto_yes:
        # We use standard input for compatibility with generic environments
        custom_name = input(f"      Swarm Name [{project_name}]: ").strip()
        if custom_name: project_name = custom_name
        
        cluster = input("      Enable P2P Redis Cluster? [Y/n]: ").strip().lower() != 'n'
        sandbox = input("      Enable Strict Sandbox Isolation? [Y/n]: ").strip().lower() != 'n'
        
        print("\\n      (Optional) API Keys for Cloud Router:")
        anthropic = input("      Anthropic API Key (Claude): ").strip()
        openai = input("      OpenAI API Key (GPT-4): ").strip()
    else:
        cluster = True
        sandbox = True
        anthropic = ""
        openai = ""
        
    # 3. Scaffold
    print("\\n[3/3] Generating Project Scaffold...")
    time.sleep(1)
    
    os.makedirs(project_name, exist_ok=True)
    
    # .env
    with open(f"{project_name}/.env", "w") as f:
        f.write(f"ANTHROPIC_API_KEY={anthropic}\\n")
        f.write(f"OPENAI_API_KEY={openai}\\n")
        f.write(f"KERNELL_CLUSTER_NAME={project_name}_swarm\\n")
        f.write("REDIS_URL=redis://localhost:6379\\n")
        f.write(f"STRICT_SANDBOX={str(sandbox).lower()}\\n")
        
    # main.py
    main_content = f"""import os
from dotenv import load_dotenv
from kernell_os_sdk import Agent, AgentPermissions
from kernell_os_sdk.llm import LLMRouter, OllamaProvider, AnthropicProvider
from kernell_os_sdk.cluster import ClusterDiscovery

load_dotenv()

def main():
    print("🚀 Booting Kernell OS Swarm: {project_name}")
    
    local = OllamaProvider(model="{local_model}")
    cloud = AnthropicProvider(model="claude-3-5-sonnet-20241022")
    router = LLMRouter(local=local, cloud=cloud, cloud_threshold="hard")
    
    director = Agent(
        name="Swarm Director",
        engine=router,
        permissions=AgentPermissions(network_access=True)
    )
    
    director.enable_delegation(max_workers=5, worker_engine=local)
"""
    if cluster:
        main_content += """
    discovery = ClusterDiscovery(redis_url=os.getenv("REDIS_URL"), cluster_name=os.getenv("KERNELL_CLUSTER_NAME"))
    discovery.join(agent_name="director_node", hardware_profile={"model": "%s"})
""" % local_model

    main_content += """
    print("✅ Swarm is online. Run 'kernell gui' to open the Command Center.")
    
if __name__ == "__main__":
    main()
"""
    with open(f"{project_name}/main.py", "w") as f:
        f.write(main_content)
        
    print(f"\\n✅ Done! Your agent swarm is ready in directory '{project_name}'")
    print(f"\\nNext Steps:")
    print(f"  cd {project_name}")
    print(f"  kernell run")
    print(f"  kernell gui")

if __name__ == "__main__":
    main()
